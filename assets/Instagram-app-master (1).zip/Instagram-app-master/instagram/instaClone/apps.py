from django.apps import AppConfig


class InstacloneConfig(AppConfig):
    name = 'instaClone'
